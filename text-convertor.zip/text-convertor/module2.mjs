const a="Ali";
const b="Asad";
export default a;
export {a};
export {b};
