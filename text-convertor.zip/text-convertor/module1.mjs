import cd, {a,b} from "./module2.mjs";
console.log(cd);
console.log(a);
console.log(b);